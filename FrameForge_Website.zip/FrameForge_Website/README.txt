FRAMEFORGE – WEBSITE-DATEIEN
=============================

Dateien:
- index.html: vollständige responsive Website (HTML, CSS und JavaScript)

VOR DER VERÖFFENTLICHUNG
------------------------
1. Prüfe die Kontaktadresse. Der Code verwendet vorläufig:
   FrameForge.bussines@gmail.com
   Du hattest "gmail.con" geschrieben, was vermutlich ein Tippfehler ist.
   Ändere die Adresse in index.html an BEIDEN Stellen, falls sie anders lautet.
2. Teste das Kontaktformular. Es öffnet das E-Mail-Programm des Besuchers
   und versendet die Nachricht nicht automatisch im Hintergrund.
3. Füge deine echten Demo-Reels ein, sobald sie fertig sind. Die Portfolio-
   Bereiche sind ausdrücklich als Konzepte gekennzeichnet, keine Referenzen.
4. Kläre mit deinen Eltern die geschäftlichen Angaben, Zahlungen und
   Vertragsbedingungen, da du minderjährig bist.
5. Prüfe die für deine Website erforderlichen Anbieter- und Datenschutzangaben.

KOSTENLOS HOSTEN MIT GITHUB PAGES
---------------------------------
1. Erstelle ein Konto auf https://github.com/
2. Erstelle ein neues Repository, z.B. "frameforge-website".
3. Lade index.html in das Repository hoch.
4. Öffne Settings > Pages.
5. Wähle als Quelle "Deploy from a branch", den Branch "main" und den Ordner "/ (root)".
6. Speichere. Nach der Veröffentlichung zeigt GitHub Pages die Website-Adresse an.
   Die Adresse kann einige Minuten brauchen, bis sie funktioniert.

Offizielle Anleitung:
https://docs.github.com/en/pages

Hinweis:
Das Hosting stellt nur die Website bereit. Das Kontaktformular nutzt mailto:
und braucht keinen Server, aber der Besucher muss ein E-Mail-Programm eingerichtet haben.
